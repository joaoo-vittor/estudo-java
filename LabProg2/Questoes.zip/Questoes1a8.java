public class Questoes1a8 {
  public static void main(String[] args) {
    int x = 2;
    int y = 3;

    // 1a
    System.out.printf("x = %d%n", x);
    // Saida: x = 2

    // 1b
    System.out.printf("Valor de %d + %d é igual %d%n", x, x, (x + x));
    // Saida: Valor de 2 + 2 é igual 4

    // 1c
    System.out.printf("x =");
    // Saida: x =

    // 1d OBS: A saida da 1c ficara na mesma linha da 1d
    System.out.printf("%d = %d%n", (x + y), (y + x));
    // Saida: 5 = 5


    // 2
    // e) y = a * (x * x * x) / 7

    // 3
    // a)
    System.out.println("1 2 3 4");

    // b)
    System.out.print("1 ");
    System.out.print("2 ");
    System.out.print("3 ");
    System.out.print("4 ");

    // c)
    System.out.printf("%d %d %d %d\n", 1, 2, 3, 4);


    // 4
    System.out.printf("*%n**%n***%n****%n*****%n");
    /* Saida:
    *
    **
    ***
    ****
    *****
    */

    // 5
    System.out.println("*");
    System.out.println("***");
    System.out.println("*****");
    System.out.println("****");
    System.out.println("**");
    /* Saida:
      *
      ***
      *****
      ****
      **
    */


    // 6
    System.out.print("*");
    System.out.println("***");
    System.out.println("*****");
    System.out.print("****");
    System.out.println("**");
    /* Saida:
    ****
    *****
    ******
    */

    // 7
    System.out.printf("%s%n%s%n%s%n", "*", "***", "*****");
    /* Saida:
    *
    ***
    ****
    */

    // 8
    System.out.print("*");
    System.out.print("***");
    System.out.print("*****");
    System.out.print("****");
    System.out.println("**");
    /* saida:
      ***************
    */

  }
}
